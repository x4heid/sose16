/*
 * Interaktionsdesign, SoSe 2015
 * Zettel 1, Aufgabe 2
 * Autor(en): ??
 */

#include <iostream>

int main(int argc, char** argv)
{
    std::cout << "Hello World!" << std::endl;
    
    return 0;
}
